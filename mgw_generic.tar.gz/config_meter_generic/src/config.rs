// config_meter_generic/src/config.rs

#[allow(unused_imports)]
use serde::{Deserialize, Serialize};
use std::error::Error;
use std::fs::File;
use std::net::IpAddr;
use anyhow::Result; // Use anyhow's Result type which encapsulates anyhow::Error
use anyhow::Context; // To provide additional context to error messages


#[derive(Debug, Deserialize)]
pub struct Config {
    pub meter_data: MeterData,
    pub write_registers: Vec<ConfigWriteRegister>,
    pub read_registers: Vec<ConfigRegister>,
}

#[derive(Debug, Deserialize)]
pub struct MeterData {
    pub ip: String,
    pub port: u16,
    pub meter_type: String, 
}

#[derive(Debug, Deserialize)]
pub struct ConfigRegister {
    pub name: String,
    pub address: u16,
}

#[derive(Debug, Deserialize)]
pub struct ConfigWriteRegister {
    pub name: String,
    pub address: u16,
    pub value: f32,
}

impl Config {
    // Change the return type to anyhow::Result, which implies anyhow::Error
    pub fn from_file(file_path: &str) -> Result<Self> {
        let file = File::open(file_path)
            .with_context(|| format!("Failed to open file: {}", file_path))?;
        let config: Config = serde_yaml::from_reader(file)
            .with_context(|| format!("Failed to parse YAML configuration from {}", file_path))?;
        Ok(config)
    }

    pub fn get_read_registers(&self) -> Vec<ConfigRegister> {
        self.read_registers.iter()
            .map(|reg| ConfigRegister { name: reg.name.clone(), address: reg.address })
            .collect()
    }

    pub fn get_write_registers(&self) -> Vec<ConfigWriteRegister> {
        self.write_registers.iter()
            .map(|reg| ConfigWriteRegister { name: reg.name.clone(), address: reg.address, value: reg.value })
            .collect()
    }

    pub fn get_meter_data(&self) -> MeterData {
        MeterData {
            ip: self.meter_data.ip.clone(),
            port: self.meter_data.port,
            meter_type: self.meter_data.meter_type.clone(),
        }
    }

    pub fn get_ip_and_port(&self) -> Result<(String, u16), Box<dyn Error>> {
        Ok((self.meter_data.ip.clone(), self.meter_data.port))
    }

    /// Checks if there are any write registers defined.
    pub fn has_write_registers(&self) -> bool {
        !self.write_registers.is_empty()
    }

}

pub fn validate_ip_and_port(ip: &str, port: u16) -> Result<(), Box<dyn Error>> {
    ip.parse::<IpAddr>()?;
    if port == 0 {
        return Err("Invalid port number".into());
    }
    Ok(())
}
