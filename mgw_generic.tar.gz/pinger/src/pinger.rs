use std::error::Error;
use tokio::process::Command;
use std::str;
use std::net::IpAddr;
use tokio::time::{timeout, Duration};

pub async fn ping_meter(ip: &str) -> Result<(), Box<dyn Error>> {
    let ip_addr: IpAddr = ip.parse()?;
    println!(r#"Inside"#);

    let command = Command::new("ping")
        .arg("-c")
        .arg("1")
        .arg(ip_addr.to_string())
        .output();

    match timeout(Duration::from_secs(2), command).await {
        Ok(Ok(output)) => {
            if output.status.success() {
                println!("Ping successful");
            } else {
                eprintln!("Ping failed: {:?}", output);
            }
        }
        Ok(Err(e)) => {
            eprintln!("Failed to execute ping: {:?}", e);
        }
        Err(e) => {
            eprintln!("Ping command timed out: {:?}", e);
        }
    }

    Ok(())
}
