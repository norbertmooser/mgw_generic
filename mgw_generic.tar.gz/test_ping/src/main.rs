use structopt::StructOpt;
use pinger::ping_meter;

/// Command line arguments structure
#[derive(StructOpt, Debug)]
#[structopt(name = "meter_ping")]
struct Opt {
    /// IP address of the meter
    #[structopt(short, long)]
    ip: String,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let opt = Opt::from_args();

    let ip = opt.ip;

    // Ping the meter
    ping_meter(&ip).await?;

    Ok(())
}
